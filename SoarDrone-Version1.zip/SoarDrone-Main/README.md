# SoarDrone

## Prerequisites
[Eclipse set up](https://www.youtube.com/watch?v=bC4XB6JAaoU)

## Change your eclipse class path
Set JavafX and Soar paths

--module-path "/Users/sleary10/Downloads/javafx-sdk-11.0.2/lib" --add-modules javafx.controls,javafx.fxml -Djava.library.path=/Users/sleary10/Documents/SoarSuite_9.6.0-Multiplatform_64bit/bin/ -cp /Users/sleary10/Documents/SoarSuite_9.6.0-Multiplatform_64bit/bin/java/sml.jar:.



